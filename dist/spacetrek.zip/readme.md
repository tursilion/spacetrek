19880601

Space Trek documents.......

Space Trek was written by Mike Ward.

There are 14 commands you can enter. Here they are:

	1) change speed
	2) change direction
	3) status report
	4) teleport for sabotage
	5) sensor map
	6) change shield power
	7) change phasor power
	8) fire phasors
	9) fire photon torpedo
	10) dock or land
	11) self-destruct
	12) send for help
	13) do nothing
	14) immediate repair

Some commands need explanation:

- Teleport - allows you to send crew to nearby (2 units) enemy ships in order to sabotage and destroy them
- Sensor map - option 1 is immediate area with 1:1 scale while option 2 is whole galaxy (1:5 scale)
- Dock or land - base or planet must be one space away. A starbase will fix everything but a planet only fixes some.
- Send for help - a starbase will send an energy beam to refuel you.
- Immediate repair - repair is always being done on the ship (though less at higher speeds). This option makes the crew concentrate on one item. The item numbers are:

	1) engines
	2) teleport
	3) sensors
	4) shield control
	5) phasor banks
	6) torpedo bay
	7) communications lines

The game is over if you win (by destroying all the dingdons), run out of energy or run into something. Good luck, captain!

The game only works under TI BASIC with CALL FILES(1), or Extended BASIC with memory expansion.

Load DSK1.SPACETREK for the game. DSK1.STDOCS has a copy of this documentation.
